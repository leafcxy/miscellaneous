namespace BootstrapExtensions.Base.Button
{
    public enum Category
    {
        Primary, Info, Success, Warning, Danger, Inverse, Link
    }
}