namespace BootstrapExtensions.Base.Form
{
    public enum FormLayout
    {
        Default, Search, Inline, Horizontal
    }
}