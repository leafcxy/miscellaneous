namespace BootstrapExtensions.Base.Button
{
    public enum Size
    {
        Large, Default, Small, Mini
    }
}