namespace BootstrapExtensions.Base.Button
{
    public enum Tag
    {
        A, Button, Input
    }
}